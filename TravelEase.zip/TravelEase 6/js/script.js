const STORE={users:'travelEaseUsers',bookings:'travelEaseBookings',messages:'travelEaseMessages',packages:'travelEasePackages',admin:'travelEaseAdminProfile'};
const seedPackages=[{id:1,name:'Bali Holiday Package',destination:'Bali, Indonesia',price:28999,duration:'5 Days / 4 Nights',image:'images/bali.jpg',status:'Active'},{id:2,name:'Dubai Explorer',destination:'Dubai, UAE',price:34999,duration:'4 Days / 3 Nights',image:'images/Dubai.jpg',status:'Active'},{id:3,name:'Thailand Getaway',destination:'Thailand',price:24999,duration:'6 Days / 5 Nights',image:'images/thailand.jpg',status:'Active'},{id:4,name:'Switzerland Escape',destination:'Switzerland',price:74999,duration:'7 Days / 6 Nights',image:'images/switzerland.jpg',status:'Active'},{id:5,name:'Maldives Paradise',destination:'Maldives',price:49999,duration:'4 Days / 3 Nights',image:'images/maldives.jpg',status:'Active'},{id:6,name:'Singapore Tour',destination:'Singapore',price:32999,duration:'5 Days / 4 Nights',image:'images/singapore.jpg',status:'Active'}];
function get(key,fallback=[]){try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}}function put(key,val){localStorage.setItem(key,JSON.stringify(val))}function money(n){return Number(n||0).toLocaleString('en-IN')}function toast(msg){let el=document.getElementById('toast');if(!el){el=document.createElement('div');el.id='toast';el.className='toast';document.body.append(el)}el.textContent=msg;el.style.display='block';setTimeout(()=>el.style.display='none',2800)}function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
if(!localStorage.getItem(STORE.packages))put(STORE.packages,seedPackages);
// Newsletter
 document.querySelectorAll('.newsletter').forEach(f=>f.addEventListener('submit',e=>{e.preventDefault();toast('Thanks for subscribing to TravelEase!');f.reset()}));
// Contact form
const cf=document.getElementById('contactForm');
if(cf) cf.addEventListener('submit',e=>{
 e.preventDefault();
 const name=document.getElementById('contactName').value.trim();
 const email=document.getElementById('contactEmail').value.trim();
 const subject=document.getElementById('contactSubject').value.trim();
 const message=document.getElementById('contactMessage').value.trim();
 if(!name||!email||!subject||!message){toast('Please complete all contact fields.');return;}
 const messages=get(STORE.messages);
 messages.unshift({id:'MSG'+Date.now(),name,email,subject,message,date:new Date().toISOString(),status:'Unread'});
 put(STORE.messages,messages);
 const notice=document.getElementById('contactNotice');
 if(notice){notice.textContent='Thank you! Your message has been sent and saved.';notice.style.display='block';}
 cf.reset();
 toast('Message submitted successfully!');
});
// Registration validation helpers (shared by Client and Admin registration)
function showFormNotice(id,message,success=false){
 const box=document.getElementById(id);
 if(!box)return;
 box.textContent=message;
 box.style.display='block';
 box.style.color=success?'#176b3a':'#b42318';
 box.setAttribute('role','alert');
}
function validateRegistration(data){
 // 1. Required fields
 if(Object.values(data).some(value=>String(value??'').trim()==='')){
  return 'All fields are required. Please complete the form.';
 }
 // 2. Email format
 const emailPattern=/^[^\s@]+@[^\s@]+\.[A-Za-z]{2,}$/;
 if(!emailPattern.test(data.email)){
  return 'Please enter a valid email address (example: name@example.com).';
 }
 // 3. Phone number format (10 digits, Indian mobile number)
 const phonePattern=/^[6-9]\d{9}$/;
 if(!phonePattern.test(data.phone)){
  return 'Enter a valid 10-digit mobile number starting with 6, 7, 8 or 9.';
 }
 // 4. Password length
 if(data.password.length<8){
  return 'Password must contain at least 8 characters.';
 }
 // 5. Password pattern
 const passwordPattern=/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;
 if(!passwordPattern.test(data.password)){
  return 'Password must include uppercase, lowercase, number and special character.';
 }
 if(data.password!==data.confirmPassword){
  return 'Password and confirm password do not match.';
 }
 return '';
}
// Client Login / Registration
function authMode(mode){
 const login=mode==='login';
 const loginForm=document.getElementById('loginForm'),registerForm=document.getElementById('registerForm');
 if(!loginForm||!registerForm)return;
 loginForm.style.display=login?'block':'none';
 registerForm.style.display=login?'none':'block';
 document.getElementById('loginTab')?.classList.toggle('active',login);
 document.getElementById('registerTab')?.classList.toggle('active',!login);
 const title=document.getElementById('authTitle'),subtitle=document.getElementById('authSubtitle');
 if(title)title.textContent=login?'Welcome Back!':'Create Your Account';
 if(subtitle)subtitle.textContent=login?'Login to your account':'Register to start planning your journey';
}
if(document.getElementById('loginTab')){
 document.getElementById('loginTab').addEventListener('click',()=>authMode('login'));
 document.getElementById('registerTab').addEventListener('click',()=>authMode('register'));
 document.getElementById('registerLink')?.addEventListener('click',e=>{e.preventDefault();authMode('register');});
 document.getElementById('loginLink')?.addEventListener('click',e=>{e.preventDefault();authMode('login');});
}
const clientRegisterForm=document.getElementById('registerForm');
if(clientRegisterForm)clientRegisterForm.addEventListener('submit',e=>{
 e.preventDefault();
 const field=id=>document.getElementById(id)?.value??'';
 const data={name:field('registerName'),email:field('registerEmail').trim(),phone:field('registerPhone').trim(),password:field('registerPassword'),confirmPassword:field('confirmPassword')};
 const error=validateRegistration(data);
 if(error){showFormNotice('authNotice',error);return;}
 const users=get(STORE.users);
 if(users.some(u=>u.email.toLowerCase()===data.email.toLowerCase())){
  showFormNotice('authNotice','An account with this email already exists.');return;
 }
 users.push({id:Date.now(),name:data.name.trim(),email:data.email,phone:data.phone,password:data.password,role:'User',status:'Active',joined:new Date().toISOString()});
 put(STORE.users,users);
 showFormNotice('authNotice','Account created successfully. You can now log in.',true);
 clientRegisterForm.reset();
 authMode('login');
});
// Client Login
const clientLoginForm=document.getElementById('loginForm');
if(clientLoginForm)clientLoginForm.addEventListener('submit',e=>{
 e.preventDefault();
 const email=document.getElementById('loginEmail').value.trim();
 const password=document.getElementById('loginPassword').value;
 const user=get(STORE.users).find(x=>x.email.toLowerCase()===email.toLowerCase()&&x.password===password);
 if(!user){showFormNotice('authNotice','Account not found or password is incorrect. Please register first.');return;}
 sessionStorage.setItem('travelEaseUser',JSON.stringify({id:user.id,name:user.name,email:user.email}));
 toast('Login successful!');
 setTimeout(()=>location.href='my-bookings.html',700);
});
// Admin Registration
const adminRegisterForm=document.getElementById('adminRegisterForm');
if(adminRegisterForm)adminRegisterForm.addEventListener('submit',e=>{
 e.preventDefault();
 const field=id=>document.getElementById(id)?.value??'';
 const data={name:field('adminRegisterName'),email:field('adminRegisterEmail').trim(),phone:field('adminRegisterPhone').trim(),password:field('adminRegisterPassword'),confirmPassword:field('adminConfirmPassword')};
 const error=validateRegistration(data);
 if(error){showFormNotice('adminRegisterNotice',error);return;}
 put(STORE.admin,{name:data.name.trim(),email:data.email,phone:data.phone,password:data.password,updated:new Date().toISOString()});
 showFormNotice('adminRegisterNotice','Admin account created successfully. You can now log in.',true);
 adminRegisterForm.reset();
 setTimeout(()=>location.href='admin-login.html',900);
});
// Admin Login
const adminLoginFormEl=document.getElementById('adminLoginForm');
if(adminLoginFormEl)adminLoginFormEl.addEventListener('submit',e=>{
 e.preventDefault();
 const profile=get(STORE.admin,{email:'admin@travelease.com',password:'admin123'});
 const email=document.getElementById('adminLoginEmail').value.trim();
 const password=document.getElementById('adminLoginPassword').value;
 if(email===profile.email&&password===(profile.password||'admin123')){
  sessionStorage.setItem('travelEaseAdminLoggedIn','1');
  location.href='admin-dashboard.html';
 }else showFormNotice('adminLoginNotice','Invalid admin credentials.');
});
// Booking: use explicit element lookups for Safari compatibility
const bookingFormEl=document.getElementById('bookingForm');
if(bookingFormEl) bookingFormEl.addEventListener('submit',e=>{
 e.preventDefault();
 const el=id=>document.getElementById(id);
 const packageEl=el('bookingPackage');
 const selected=packageEl.options[packageEl.selectedIndex];
 const count=Number(el('travellers').value);
 const pkg=packageEl.value;
 if(!pkg||!selected||!count){toast('Please complete the booking details.');return;}
 const item={
  id:'TEB'+String(Date.now()).slice(-7),
  name:el('bookingName').value.trim(),
  email:el('bookingEmail').value.trim(),
  phone:el('bookingPhone').value.trim(),
  package:pkg,
  travelDate:el('travelDate').value,
  travellers:count,
  amount:Number(selected.dataset.price||0)*count,
  requirements:el('requirements').value.trim(),
  status:'Pending',
  created:new Date().toISOString()
 };
 const bookings=get(STORE.bookings);
 bookings.unshift(item);
 put(STORE.bookings,bookings);
 addPaymentFromBooking(item);
 const notice=el('bookingNotice');
 if(notice){notice.textContent='Booking request submitted! Your booking ID is '+item.id+'.';notice.style.display='block';}
 bookingFormEl.reset();
 toast('Booking request saved successfully!');
});
// My bookings
if(document.getElementById('myBookingsBody')){let user=JSON.parse(sessionStorage.getItem('travelEaseUser')||'null'),all=get(STORE.bookings),mine=user?all.filter(b=>b.email===user.email):all;myBookingsBody.innerHTML=mine.map(b=>`<tr><td>${esc(b.id)}</td><td>${esc(b.name)}</td><td>${esc(b.package)}</td><td>${esc(b.travelDate)}</td><td>${b.travellers}</td><td>₹${money(b.amount)}</td><td><span class="status ${b.status.toLowerCase()}">${esc(b.status)}</span></td></tr>`).join('');myBookingsEmpty.style.display=mine.length?'none':'block'}
// Admin logout
if(document.getElementById('adminLogout'))adminLogout.onclick=()=>{sessionStorage.removeItem('travelEaseAdminLoggedIn');location.href='admin-login.html'};
// Dashboard
if(document.getElementById('statPackages')){let b=get(STORE.bookings),u=get(STORE.users),p=get(STORE.packages);statPackages.textContent=p.length;statUsers.textContent=u.length;statPending.textContent=b.filter(x=>x.status==='Pending').length;statRevenue.textContent='₹'+money(b.filter(x=>x.status==='Confirmed').reduce((s,x)=>s+x.amount,0));recentAdminBookings.innerHTML=b.slice(0,5).map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.package)}</td><td>${esc(x.travelDate)}</td><td><span class="status ${x.status.toLowerCase()}">${x.status}</span></td></tr>`).join('')||'<tr><td colspan="4" class="empty">No booking requests yet.</td></tr>';adminDestinations.innerHTML=p.slice(0,3).map(x=>`<div><img src="${esc(x.image)}" style="width:100%;height:75px;object-fit:cover;border-radius:7px"><small>${esc(x.destination)}</small></div>`).join('')}
// Admin packages CRUD
function renderAdminPackages(){if(!document.getElementById('adminPackagesBody'))return;let p=get(STORE.packages),q=adminPackageSearch.value.toLowerCase(),s=packageStatusFilter.value;let list=p.filter(x=>(x.name+' '+x.destination).toLowerCase().includes(q)&&(s==='all'||x.status===s));adminPackagesBody.innerHTML=list.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.name)}</td><td>${esc(x.destination)}</td><td>${esc(x.duration)}</td><td>${money(x.price)}</td><td><span class="status ${x.status==='Inactive'?'inactive':''}">${x.status}</span></td><td><button class="btn btn-outline btn-sm" onclick="editPackage(${x.id})">Edit</button> <button class="btn btn-sm" onclick="deletePackage(${x.id})">Delete</button></td></tr>`).join('')||'<tr><td colspan="7" class="empty">No packages found.</td></tr>'}
function editPackage(id){let x=get(STORE.packages).find(x=>x.id===id);if(!x)return;packageEditor.style.display='block';packageEditorTitle.textContent='Edit Package';editPackageId.value=x.id;editPackageName.value=x.name;editDestination.value=x.destination;editPrice.value=x.price;editDuration.value=x.duration;editImage.value=x.image;editStatus.value=x.status;packageEditor.scrollIntoView({behavior:'smooth'})}function deletePackage(id){if(!confirm('Delete this package?'))return;put(STORE.packages,get(STORE.packages).filter(x=>x.id!==id));renderAdminPackages();toast('Package deleted')}if(document.getElementById('adminPackagesBody')){adminPackageSearch.oninput=renderAdminPackages;packageStatusFilter.onchange=renderAdminPackages;addPackageBtn.onclick=()=>{adminPackageForm.reset();editPackageId.value='';packageEditorTitle.textContent='Add New Package';packageEditor.style.display='block';packageEditor.scrollIntoView({behavior:'smooth'})};cancelPackageEdit.onclick=()=>packageEditor.style.display='none';adminPackageForm.onsubmit=e=>{e.preventDefault();let a=get(STORE.packages),id=Number(editPackageId.value),obj={id:id||Date.now(),name:editPackageName.value,destination:editDestination.value,price:Number(editPrice.value),duration:editDuration.value,image:editImage.value||'images/hero.jpg',status:editStatus.value};if(id)a=a.map(x=>x.id===id?obj:x);else a.push(obj);put(STORE.packages,a);packageEditor.style.display='none';renderAdminPackages();toast('Package saved successfully')};renderAdminPackages()}
// Admin users
function renderUsers(){if(!document.getElementById('adminUsersBody'))return;let q=userSearch.value.toLowerCase(),s=userStatus.value,a=get(STORE.users).filter(x=>(x.name+' '+x.email).toLowerCase().includes(q)&&(s==='all'||x.status===s));adminUsersBody.innerHTML=a.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.name)}</td><td>${esc(x.email)}</td><td>${esc(x.phone||'—')}</td><td>${esc(x.role||'User')}</td><td>${new Date(x.joined||Date.now()).toLocaleDateString('en-IN')}</td><td><span class="status ${x.status==='Inactive'?'inactive':''}">${x.status||'Active'}</span></td><td><button class="btn btn-outline btn-sm" onclick="toggleUser(${x.id})">${x.status==='Inactive'?'Activate':'Disable'}</button></td></tr>`).join('')||'<tr><td colspan="8" class="empty">No users registered yet.</td></tr>'}function toggleUser(id){let a=get(STORE.users);a=a.map(x=>x.id===id?{...x,status:x.status==='Inactive'?'Active':'Inactive'}:x);put(STORE.users,a);renderUsers()}if(document.getElementById('adminUsersBody')){userSearch.oninput=renderUsers;userStatus.onchange=renderUsers;renderUsers()}
// Admin bookings
function renderBookings(){
 const body=document.getElementById('adminBookingsBody');if(!body)return;
 const search=(document.getElementById('bookingSearch')?.value||'').toLowerCase();
 const filter=document.getElementById('bookingFilter')?.value||'all';
 const all=get(STORE.bookings);
 const rows=all.filter(x=>(String(x.name||'')+' '+String(x.package||'')+' '+String(x.id||'')).toLowerCase().includes(search)&&(filter==='all'||x.status===filter));
 body.innerHTML=rows.map(x=>`<tr><td>${esc(x.id)}</td><td>${esc(x.name)}</td><td>${esc(x.package)}</td><td>${esc(x.travelDate)}</td><td>${Number(x.travellers)||1}</td><td>${money(x.amount)}</td><td><span class="status ${String(x.status||'Pending').toLowerCase()}">${esc(x.status||'Pending')}</span></td><td><button class="btn btn-sm" onclick="setBookingStatus('${esc(x.id)}','Confirmed')">✓ Confirm</button> <button class="btn btn-outline btn-sm" onclick="setBookingStatus('${esc(x.id)}','Cancelled')">× Cancel</button></td></tr>`).join('')||'<tr><td colspan="8" class="empty">No booking requests found.</td></tr>';
 const set=(id,val)=>{const node=document.getElementById(id);if(node)node.textContent=val;};
 set('bookingTotal',all.length);
 set('bookingPending',all.filter(x=>x.status==='Pending').length);
 set('bookingConfirmed',all.filter(x=>x.status==='Confirmed').length);
 set('bookingCancelled',all.filter(x=>x.status==='Cancelled').length);
}
function setBookingStatus(id,status){put(STORE.bookings,get(STORE.bookings).map(x=>x.id===id?{...x,status}:x));renderBookings();toast('Booking updated: '+status);}
if(document.getElementById('adminBookingsBody')){
 const searchEl=document.getElementById('bookingSearch'),filterEl=document.getElementById('bookingFilter');
 if(searchEl)searchEl.addEventListener('input',renderBookings);
 if(filterEl)filterEl.addEventListener('change',renderBookings);
 renderBookings();
}
// Profile
if(document.getElementById('adminProfileForm')){let p=get(STORE.admin,{name:'Admin User',email:'admin@travelease.com',phone:'+91 98765 43210',password:'admin123'});adminName.value=p.name;adminEmail.value=p.email;adminPhone.value=p.phone;adminProfileForm.onsubmit=e=>{e.preventDefault();put(STORE.admin,{...p,name:adminName.value,email:adminEmail.value,phone:adminPhone.value});toast('Profile updated');};adminPasswordForm.onsubmit=e=>{e.preventDefault();let n=newAdminPassword.value;if(currentAdminPassword.value!==(p.password||'admin123')){alert('Current password is incorrect');return}if(n!==confirmAdminPassword.value){alert('New passwords do not match');return}p.password=n;put(STORE.admin,p);adminPasswordForm.reset();toast('Password updated')}}


// CUSTOMER REVIEWS - shared browser storage between client and admin pages
const REVIEW_STORE='travelEaseReviews';
const reviewForm=document.getElementById('reviewForm');
if(reviewForm){
 reviewForm.addEventListener('submit',function(e){
  e.preventDefault();
  const field=id=>document.getElementById(id);
  const name=field('reviewName').value.trim();
  const email=field('reviewEmail').value.trim();
  const destination=field('reviewDestination').value;
  const rating=Number(field('reviewRating').value);
  const comment=field('reviewComment').value.trim();
  if(!name||!email||!destination||rating<1||rating>5||comment.length<8){
   toast('Please complete every review field and choose a rating.');return;
  }
  const reviews=get(REVIEW_STORE,[]);
  reviews.unshift({id:'REV'+Date.now(),name,email,destination,rating,comment,date:new Date().toISOString(),status:'Pending'});
  try{put(REVIEW_STORE,reviews);}catch(err){toast('Could not save review. Please check browser storage settings.');return;}
  const notice=field('reviewNotice');
  if(notice){notice.textContent='Thank you! Your review was submitted and is awaiting admin approval.';notice.style.display='block';}
  reviewForm.reset();
  renderCustomerReviews();
  renderPublicReviews();
  toast('Review submitted successfully!');
 });
 renderCustomerReviews();
}
function renderCustomerReviews(){
 const body=document.getElementById('customerReviewsBody');if(!body)return;
 const email=(JSON.parse(sessionStorage.getItem('travelEaseUser')||'null')||{}).email;
 const reviews=get(REVIEW_STORE,[]).filter(r=>!email||String(r.email).toLowerCase()===String(email).toLowerCase());
 body.innerHTML=reviews.map(r=>`<tr><td>${esc(r.destination)}</td><td>${'★'.repeat(Number(r.rating)||0)}${'☆'.repeat(5-(Number(r.rating)||0))}</td><td><span class="status ${String(r.status).toLowerCase()}">${esc(r.status)}</span></td><td>${new Date(r.date).toLocaleDateString('en-IN')}</td></tr>`).join('')||'<tr><td colspan="4" class="empty">No reviews submitted yet.</td></tr>';
}
function renderAdminReviews(){
 const body=document.getElementById('adminReviewsBody');if(!body)return;
 const reviews=get(REVIEW_STORE,[]);
 body.innerHTML=reviews.map(r=>`<tr><td>${esc(r.name)}<br><small>${esc(r.email)}</small></td><td>${esc(r.destination)}</td><td>${'★'.repeat(Number(r.rating)||0)}${'☆'.repeat(5-(Number(r.rating)||0))}</td><td>${esc(r.comment)}</td><td><span class="status ${String(r.status).toLowerCase()}">${esc(r.status)}</span></td><td><button class="btn btn-sm" onclick="setReviewStatus('${r.id}','Approved')">Approve</button> <button class="btn btn-outline btn-sm" onclick="setReviewStatus('${r.id}','Rejected')">Reject</button> <button class="btn btn-outline btn-sm" onclick="deleteReview('${r.id}')">Delete</button></td></tr>`).join('')||'<tr><td colspan="6" class="empty">No customer reviews have been submitted yet.</td></tr>';
 const count=document.getElementById('reviewCount');if(count)count.textContent=reviews.length;
}
function setReviewStatus(id,status){put(REVIEW_STORE,get(REVIEW_STORE,[]).map(r=>r.id===id?{...r,status}:r));renderAdminReviews();renderPublicReviews();toast('Review '+status.toLowerCase()+'.');}
function deleteReview(id){if(!confirm('Delete this review?'))return;put(REVIEW_STORE,get(REVIEW_STORE,[]).filter(r=>r.id!==id));renderAdminReviews();toast('Review deleted.');}
if(document.getElementById('adminReviewsBody'))renderAdminReviews();
function renderPublicReviews(){
 const box=document.getElementById('publicReviews');if(!box)return;
 const approved=get(REVIEW_STORE,[]).filter(r=>r.status==='Approved');
 box.innerHTML=approved.length?approved.slice(0,6).map(r=>`<article class="panel"><div style="color:#d69b22;font-size:18px">${'★'.repeat(Number(r.rating)||0)}${'☆'.repeat(5-(Number(r.rating)||0))}</div><h3 style="margin:8px 0 4px">${esc(r.destination)}</h3><p>${esc(r.comment)}</p><small style="color:var(--muted)">— ${esc(r.name)}</small></article>`).join(''):'<p class="empty">No approved reviews yet.</p>';
}
if(document.getElementById('publicReviews'))renderPublicReviews();

// ADMIN CONTACT MESSAGES
function renderAdminMessages(){
 const body=document.getElementById('adminMessagesBody');if(!body)return;
 const messages=get(STORE.messages);
 body.innerHTML=messages.map(m=>`<tr><td>${esc(m.name)}<br><small>${esc(m.email)}</small></td><td>${esc(m.subject)}</td><td>${esc(m.message)}</td><td>${new Date(m.date).toLocaleString('en-IN')}</td><td><span class="status ${m.status==='Read'?'confirmed':'pending'}">${esc(m.status||'Unread')}</span></td><td><button class="btn btn-sm" onclick="markMessageRead('${m.id}')">Mark Read</button> <button class="btn btn-outline btn-sm" onclick="deleteMessage('${m.id}')">Delete</button></td></tr>`).join('')||'<tr><td colspan="6" class="empty">No contact messages received yet.</td></tr>';
 const count=document.getElementById('messageCount');if(count)count.textContent=messages.filter(m=>m.status!=='Read').length;
}
function markMessageRead(id){put(STORE.messages,get(STORE.messages).map(m=>m.id===id?{...m,status:'Read'}:m));renderAdminMessages();toast('Message marked as read.')}
function deleteMessage(id){if(!confirm('Delete this message?'))return;put(STORE.messages,get(STORE.messages).filter(m=>m.id!==id));renderAdminMessages();toast('Message deleted.')}
if(document.getElementById('adminMessagesBody'))renderAdminMessages();

function renderPublicReviews(){
 const box=document.getElementById('publicReviews');if(!box)return;
 const approved=get(REVIEW_STORE).filter(r=>r.status==='Approved');
 box.innerHTML=approved.length?approved.slice(0,6).map(r=>`<article class="panel"><div style="color:#d69b22;font-size:18px">${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</div><h3 style="margin:8px 0 4px">${esc(r.destination)}</h3><p>${esc(r.comment)}</p><small style="color:var(--muted)">— ${esc(r.name)}</small></article>`).join(''):'<p class="empty">No approved reviews yet. Be the first to share your experience!</p>';
}
if(document.getElementById('publicReviews'))renderPublicReviews();


// ADMIN PAYMENTS - demo payment ledger linked to booking requests
const PAYMENT_STORE='travelEasePayments';
function addPaymentFromBooking(booking){
 const payments=get(PAYMENT_STORE,[]);
 if(payments.some(p=>p.bookingId===booking.id))return;
 payments.unshift({
  id:'PAY'+String(Date.now()).slice(-8),
  bookingId:booking.id,
  customer:booking.name,
  email:booking.email,
  package:booking.package,
  date:booking.created||new Date().toISOString(),
  amount:Number(booking.amount)||0,
  method:'Not recorded',
  status:'Pending'
 });
 put(PAYMENT_STORE,payments);
}
function syncPaymentRecords(){
 const payments=get(PAYMENT_STORE,[]);
 const bookings=get(STORE.bookings,[]);
 bookings.forEach(b=>{
  if(!payments.some(p=>p.bookingId===b.id)){
   payments.push({id:'PAY'+String(b.id||Date.now()).replace(/\D/g,'').slice(-8),bookingId:b.id,customer:b.name,email:b.email,package:b.package,date:b.created||new Date().toISOString(),amount:Number(b.amount)||0,method:'Not recorded',status:'Pending'});
  }
 });
 put(PAYMENT_STORE,payments);
}
function renderAdminPayments(){
 const body=document.getElementById('adminPaymentsBody');if(!body)return;
 syncPaymentRecords();
 const all=get(PAYMENT_STORE,[]);
 const search=(document.getElementById('paymentSearch')?.value||'').toLowerCase();
 const filter=document.getElementById('paymentFilter')?.value||'all';
 const visible=all.filter(p=>([p.id,p.bookingId,p.customer,p.package].join(' ').toLowerCase().includes(search))&&(filter==='all'||p.status===filter));
 body.innerHTML=visible.map(p=>{
  const actions=p.status==='Pending'
   ? `<button class="btn btn-sm" onclick="updatePaymentStatus('${p.id}','Paid')">Mark Paid</button> <button class="btn btn-outline btn-sm" onclick="updatePaymentStatus('${p.id}','Failed')">Mark Failed</button>`
   : p.status==='Paid' ? `<button class="btn btn-outline btn-sm" onclick="updatePaymentStatus('${p.id}','Refunded')">Record Refund</button>` : '—';
  return `<tr><td>${esc(p.id)}</td><td>${esc(p.bookingId)}</td><td>${esc(p.customer)}<br><small>${esc(p.email)}</small></td><td>${esc(p.package)}</td><td>${new Date(p.date).toLocaleDateString('en-IN')}</td><td>₹${money(p.amount)}</td><td>${esc(p.method||'Not recorded')}</td><td><span class="status ${String(p.status).toLowerCase()}">${esc(p.status)}</span></td><td>${actions}</td></tr>`;
 }).join('')||'<tr><td colspan="9" class="empty">No payment records yet. Create a customer booking to generate a payment record.</td></tr>';
 const set=(id,value)=>{const el=document.getElementById(id);if(el)el.textContent=value;};
 set('paymentTotal',all.length);
 set('paymentCollected','₹'+money(all.filter(p=>p.status==='Paid').reduce((n,p)=>n+Number(p.amount||0),0)));
 set('paymentPending','₹'+money(all.filter(p=>p.status==='Pending').reduce((n,p)=>n+Number(p.amount||0),0)));
 set('paymentRefunded','₹'+money(all.filter(p=>p.status==='Refunded').reduce((n,p)=>n+Number(p.amount||0),0)));
}
function updatePaymentStatus(id,status){
 const payments=get(PAYMENT_STORE,[]);
 const updated=payments.map(p=>p.id===id?{...p,status,method:status==='Paid'?'Manual (Demo)':(p.method||'Not recorded'),updated:new Date().toISOString()}:p);
 put(PAYMENT_STORE,updated);
 renderAdminPayments();
 toast('Payment record updated: '+status+'.');
}
if(document.getElementById('adminPaymentsBody')){
 const search=document.getElementById('paymentSearch'),filter=document.getElementById('paymentFilter');
 if(search)search.addEventListener('input',renderAdminPayments);
 if(filter)filter.addEventListener('change',renderAdminPayments);
 renderAdminPayments();
}
