TRAVELEASE - FINAL PROJECT
==========================

RUN LOCALLY:
1. Extract this ZIP once.
2. Open the extracted TravelEase folder in VS Code.
3. Start Live Server from index.html.
4. Keep the same host and port for every page (for example http://127.0.0.1:5500).
5. Client website: open index.html.
6. Admin website: open admin-login.html in a SECOND browser tab using the same host/port.
   Demo admin login: admin@travelease.com / admin123
7. Customer review page: open reviews.html from the client navigation.
8. Submit a review, then refresh admin-reviews.html. Approve it to show it publicly.

IMPORTANT:
- Open client and admin pages in separate tabs, but on the SAME Live Server origin.
- Do not mix localhost and 127.0.0.1; browser localStorage is separate for each origin.
- This student project uses browser localStorage, not a hosted shared database.
- To submit online, upload the WHOLE TravelEase folder to one static hosting site, keeping all files and folders. Do not upload admin HTML files separately.

PAYMENTS MODULE:
- A Pending payment record is created automatically for every new booking.
- Existing bookings are added to the payment ledger the first time Admin > Payments is opened.
- Admin can mark a demo payment Paid, Failed, or record a Refund for a Paid item.
- Mark Paid is a manual demonstration only; it does not charge a card or transfer money.

JAVASCRIPT REGISTRATION VALIDATION:
- Client registration: login.html -> Register tab.
- Admin registration: admin-register.html (also linked from admin-login.html).
- Both registration forms validate required fields, email format, 10-digit Indian mobile number,
  password minimum length (8), password complexity (uppercase, lowercase, digit, special character),
  and password confirmation.
- Demo admin login remains admin@travelease.com / admin123 until an admin account is registered.
- Registering an admin account updates the browser's demo admin profile.
